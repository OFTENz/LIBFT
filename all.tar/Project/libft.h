#ifndef MYFUNCTIONS_H
#define Exit_Failure 5
#define Sucess 5
#define MYFUNCTIONS_H

void ft_print(char *str);

#endif  